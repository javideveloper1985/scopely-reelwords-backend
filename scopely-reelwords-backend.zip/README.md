# WELCOME TO REELWORDS

## Game instructions
 - You must create words with the letters that appear on the screen. The word must exist in the game dictionary. If it exists, you will receive certain points regarding to the corresponding letter points.  

## Saved games:
 - When you have started a game, you can save your current score.
 - If you have already saved a game, you could load it if you use the same user name.

## Special commands:
 - '*exit' -> End game.  
 - '*mix' -> If you cannot find words, you can shuffle the letters with a 2 points penalty. (Only during the game)  
 - '*words' -> Show submitted words in the game. (Only during the game)  