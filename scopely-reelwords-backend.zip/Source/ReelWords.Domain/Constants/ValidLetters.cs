﻿namespace ReelWords.Domain.Constants;

public static class ValidLetters
{
    public const string English = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
}
