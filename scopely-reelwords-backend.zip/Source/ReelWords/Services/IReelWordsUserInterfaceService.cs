﻿namespace ReelWords.Services;

public interface IReelWordsUserInterfaceService : IReelWordsInputService, IReelWordsOutputService
{
}
