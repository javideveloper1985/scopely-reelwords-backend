﻿using System.Threading.Tasks;

namespace ReelWords.Main;

public interface IReelWordsGameManager
{
    Task Start();
}
