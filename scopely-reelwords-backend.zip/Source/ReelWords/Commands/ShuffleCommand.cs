﻿using ReelWords.Commands.Implementations;

namespace ReelWords.Commands;

public class ShuffleCommand : IUserGameCommand { }
