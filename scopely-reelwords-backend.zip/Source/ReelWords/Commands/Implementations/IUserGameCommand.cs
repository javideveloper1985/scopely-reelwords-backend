﻿namespace ReelWords.Commands.Implementations;

public interface IUserGameCommand { }
